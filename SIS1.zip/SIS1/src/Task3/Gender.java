package Task3;

public enum Gender {
	BOY,GIRL
}
