package Task3;

import java.util.Scanner;
import java.util.Stack;
import java.util.Vector;

public class DragonLaunch {
 
 static Vector<Person> person = new Vector<Person>(); 

 public static void main(String[] args) {
  Scanner input = new Scanner(System.in);
  String str = input.nextLine();
  for(int i = 0 ; i < str.length(); i++) {
   if(str.charAt(i)=='B') {
    Person person = new Person(Gender.BOY);
    kidnap(person);
   }else if (str.charAt(i)=='G'){
    Person person = new Person(Gender.GIRL);
    kidnap(person);
   }
   input.close();
  }
  
  System.out.println(willDragonEatOrNot());
  
 }
 
 public static void kidnap(Person p) {
  person.add(p);
 }
 
 public static Boolean willDragonEatOrNot() {
  Stack<Gender> stack = new Stack<Gender>();
  
  for(int i=0; i < person.size(); i++) {
   if(person.get(i).getGender()==Gender.GIRL ) {
    if(!stack.empty()) 
    {
     if(stack.peek()==Gender.BOY) 
     {
      stack.pop();
     }else 
     {
      stack.add(Gender.GIRL);
     }
    } else 
    {
     stack.add(Gender.GIRL);
    }
   } else 
   {
    stack.add(Gender.BOY);
   }
  }
  return stack.isEmpty();
 }

}