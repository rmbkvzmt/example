package Task3;

import Task3.Gender;

public class Person {
	 private Gender gender;
	 
	 public Gender getGender() {
	  return gender;
	 }
	 
	 public Person(Gender gender) {
	  this.gender = gender;
	 }
	 
	 public String toString() {
	  if(gender==Gender.BOY) {
	   return "Boy";
	  }
	  return "Girl";
	 }
	}

