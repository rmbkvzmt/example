package Task2;

import java.util.*;

import Task2.Student;

public class GradeBook {
	
	private double[] grades;
	
	public GradeBook(double[] grades) 
	{
		this.grades = grades;
	}

	public double[] getGrades() 
	{
		return grades;
	}
	
	public void setGrades(double[] grades) 
	{
		this.grades = grades;
	}
	
	
	public double determineClassAverage() 
	{
		double sum = 0;
		for (double grade:grades)
			sum += grade;
		return sum/grades.length;
	}
	
	public double determineClassMin() 
	{
		double min = grades[0];
		for(double grade:grades) 
		{
			if(grade < min) min = grade;
		} return min;
	}
	
	public double determineClassMax() 
	{
		double max = grades[0];
		for(double grade:grades) 
		{
			if(grade > max) max = grade;
		} return max;
	}
	
	
	public void outputBarChart() 
	{
        System.out.println("Grade distribution: ");
        double[] frequency = new double[11];
        for (double grade : grades)
            ++frequency[(int) (grade / 10)];
        for (int count = 0; count < frequency.length; count++) {
            if (count == 10)
                System.out.printf("%5d: ", 100);
            else
                System.out.printf("%02d-%02d: ", count * 10, count * 10 + 9);
            for (int stars = 0; stars < frequency[count]; stars++)
                System.out.print("*");
            System.out.println();
        }
    }
	
	public void displayGradeReport() 
	{		
		System.out.println("Class average is "+ determineClassAverage() + ".\nLowest grade is " + determineClassMin() + ".\nHighest grade is " + determineClassMax() );
		outputBarChart();
	}
	
	public static void outputAll() 
	{
		Scanner input = new Scanner(System.in);
		Student stu1 = new Student("Student A", 18);
		Student stu2 = new Student("Student B", 56);
		Student stu3 = new Student("Student C", 88);
		Student stu4 = new Student("Student D", 68);
		Student stu5 = new Student("Student E", 42);
		Student stu6 = new Student("Student F", 31);
		stu1.output(stu1);
		double a = input.nextDouble();
		stu2.output(stu2);
		double b = input.nextDouble();
		stu3.output(stu3);
		double c = input.nextDouble();
		stu4.output(stu4);
		double d = input.nextDouble();
		stu5.output(stu5);
		double e = input.nextDouble();
		stu6.output(stu6);
		double f = input.nextDouble();

		double[] gradesArr = {a, b, c, d, e, f};
		input.close();
		
		GradeBook gb = new GradeBook(gradesArr);
		gb.displayGradeReport();
	}
	

}
