package Task2;

import Task2.GradeBook;

public class GradeBookTest {
	
	
	static 
	{
		System.out.println("Welcome to the grade book for CS101 Object-oriented Programming and Design!\n");
		System.out.println("Please, input grades for students:");
	}

	public static void main(String[] args) {
		GradeBook.outputAll();
	}

}
