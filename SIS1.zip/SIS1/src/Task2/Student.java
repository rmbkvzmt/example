package Task2;

public class Student {
	
	private String name;
	private int id;
	Student(String name, int id)
	{
		this.name = name;
		this.id = id;
	}
	
	public String getName() 
	{
		return name;
	}
	
	public void setName(String name) 
	{
		this.name = name;
	}
	
	public int getId() 
	{
		return id;
	}
	
	public void setId(int id) 
	{
		this.id = id;
	}
	
	public void output(Student st) 
	{
		System.out.print(st.getName() + ":" + " ");
	} 
}


	
	/*public Student(List<Student> stud) 
	{
		this.stud = stud;
	}
	
	public List<Student> toString(List<Student> stud) 
	{
		System.out.println("The grades are:\n" );
		Student stu1 = new Student("A", 10);
		Student stu2 = new Student("B", 16);
		Student stu3 = new Student("C", 95);
		Student stu4 = new Student("D", 84);
		Student stu5 = new Student("E", 23);
		Student stu6 = new Student("F", 24);
		List<Student> stu = Arrays.asList(stu1, stu2, stu3, stu4, stu5, stu6);
		return stu;
	}

}*/
