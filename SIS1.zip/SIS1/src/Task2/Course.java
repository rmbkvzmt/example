package Task2;

import java.util.*;

public class Course 
{	
	private String name;
	private int credits;
	private String prerequisite;
	private List<Course> crs;
	
	public Course(String name, int credits) 
	{
		this.name = name;
		this.credits = credits;
	}
	
	public String getName() 
	{
		return name;
	}
	
	public void setName(String name) 
	{
		this.name = name;
	}
	
	public int getCredits() 
	{
		return credits;
	}
	
	public void setCredits(int credits) 
	{
		this.credits = credits;
	}
	
	public String getPrerequisite() 
	{
		return prerequisite;
	}
	
	public void setPrerequisite(String prerequisite) 
	{
		this.prerequisite = prerequisite;
	}
	
	public List<Course> getCrs()
	{
		return crs;
	}
	
	public void setCrs(List<Course> crs) 
	{
		this.crs = crs;
	}
	
	public List<Course> toString(List<Course> crs) 
	{
		Course crs1 = new Course("Discrete mathematics", 3);
		Course crs2 = new Course("Principles of programming 1", 4);
		Course crs3 = new Course("Linear algebra for engineers ", 3);
		Course crs4 = new Course("Physics 1", 2);
		Course crs5 = new Course("Object-oriented programming", 3);
		Course crs6 = new Course("English(B2)", 3);
		List<Course> crs0 = Arrays.asList(crs1, crs2, crs3, crs4, crs5, crs6);
		return crs0;
	}
	
	public String toString() 
	{
		return name + " " + credits + " " + prerequisite +  " " + crs;
	}
}
