package Task1;

import java.util.Scanner;

public class Temperature {
	private double temp;
	private char scale;
	
	public Temperature(double temp)
	{
		this.temp = temp;
		scale = 'C';
	}
	
	public Temperature(char scale) 
	{
		
		this.scale = scale;
		
		this.temp = 0;
	}
	public Temperature(double temp, char scale) 
	{
		this.scale = 'C';
		if (scale == 'F') 
		{
			this.scale = scale;
		}
		this.temp = temp;
	}
	
	public Temperature() 
	{
		temp = 0;
		scale = 'C';
	}
	
	public double getTemp()
	{
		return temp;
	}
	
	public void setTemp(double temp) 
	{
		this.temp = temp;
	}
	
	public char getScale() 
	{
		return scale;
	}
	
	public void setScale(char scale) 
	{
		this.scale = scale;
	}
	
	public void setBoth(double temp, char scale) 
	{
		this.temp = temp;
		this.scale = scale;		
	}
	
	public String toString() 
	{
		return temp + " " + scale;
	}
	
	double toCelcius(double temp, char scale) 
	{
		if(scale == 'C') 
		{
			return temp;
		}
		else if (scale == 'F') 
		{
			return ((5*(temp - 32))/9);
		}
		return temp;
	}
	
	double toFahrenheit(double temp, char scale) 
	{
		if(scale == 'F')
		{
			return temp;
		} 
		else if (scale == 'C')
		{
			return ((9*(temp/5)) + 32);
		} 
		return temp;
	}
	
	
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter your degree:");
		double temp = input.nextDouble();
		System.out.println("Enter your scale ('C' for Celsius or 'F' for Fahrenheit):");
		char scale = input.next().charAt(0);
		input.close();
		
		Temperature t1 = new Temperature(temp, scale);
		System.out.println("Your degree in Celsius: " + t1.toCelcius(temp, scale) + " " + 'C');
		System.out.println("Your degree in Fahrenheit: " + t1.toFahrenheit(temp, scale) + " " + 'F');		
		
	}

}
