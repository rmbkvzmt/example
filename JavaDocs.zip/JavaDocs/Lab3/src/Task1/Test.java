package Task1;

public class Test {

 public static void main(String[] args) {
  Cat cat=new Cat("Kot");
  cat.life(false);
  cat.life();
  
  cat.printName();
 }
}