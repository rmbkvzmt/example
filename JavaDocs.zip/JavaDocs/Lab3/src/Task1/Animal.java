package Task1;

public class Animal {
 
private String name;
 
public Animal() {}

public Animal(String name)
{
  this.name=name;
}
public void life() {}

public void life(boolean isAlive) {}
 

public void printName() {
  System.out.println(name);
 }
}