package Task4;

public class Test {

	public static void main(String[] args) {
		Knight knight = new Knight(new Point(0,0));
		knight.isLegalMove(new Point(0,0), new Point(1,2));
		Rock rock = new Rock(new Point(0,0));
	    rock.isLegalMove(new Point(1,1), new Point(8,8));
	}
}
