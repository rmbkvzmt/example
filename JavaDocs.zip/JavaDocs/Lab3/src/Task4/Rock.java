package Task4;

public class Rock extends Piece{

	public Rock(Point p) {
		super(p);
	}

	public boolean isLegalMove(Point prevP, Point nextP) {
		for(int i = 1; i <= 8; i++) {
			if(prevP.x*i==nextP.x && prevP.y*i == nextP.y) {
				System.out.println("True");
				return true;
			}
		}
		return false;
	}
	
}
