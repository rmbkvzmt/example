package Task4;

public class Knight extends Piece{
	public Knight(Point p) {
		super(p);
	}
	public boolean isLegalMove(Point prevP,Point nextP) {
		if((prevP.x+1==nextP.x && prevP.y+2==nextP.y) ||
		   (prevP.x+2==nextP.x && prevP.y+1==nextP.y) ||
		   (prevP.x+2==nextP.x && prevP.y-1==nextP.y) ||
		   (prevP.x+1==nextP.x && prevP.y-2==nextP.y) ||
		   (prevP.x-1==nextP.x && prevP.y-2==nextP.y) ||
		   (prevP.x-2==nextP.x && prevP.y-1==nextP.y) ||
		   (prevP.x-2==nextP.x && prevP.y+1==nextP.y) ||
		   (prevP.x-1==nextP.x && prevP.y+2==nextP.y) 
		){
			System.out.println("True");
			return true;
		}
		System.out.println("False");
		return false;
	}	
}
