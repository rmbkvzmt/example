package Task4;

public abstract class Piece {
	Point p;
	public Piece(Point p) {
		this.p = p;
	}
	
	public abstract boolean isLegalMove(Point prevP,Point nextP);
	
}
