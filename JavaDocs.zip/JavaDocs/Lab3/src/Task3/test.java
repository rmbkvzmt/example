package Task3;
import java.util.HashSet;
import java.util.Vector;


public class test {

  public static void main(String[] args) {

    Vector<Person> v = new Vector<Person>();
    HashSet <Employee> hs=new HashSet<Employee>();
        hs.add(new Employee ("ms Swift", "Kamzina 68", 21, 70000.0));
        hs.add(new Employee ("ms Swift", "Kamzina 68", 21, 70000.0 ));
        hs.add(new Manager ( 4.5));
        System.out.print(hs.size());
        
       /* for(int i = 0; i<v.size(); i++);
          System.out.println((v.elementAt(0)).toString());
          System.out.println("\n");
          System.out.println((v.elementAt(1)).toString());
          System.out.println("\n");
          System.out.println((v.elementAt(2)).toString());
  }*/

}}