package Task2;

public class Cylinder extends Shapes{
	 private double height;
	 private double radius;
	 public Cylinder(double height,double radius) {
	  this.height=height;
	  this.radius=radius;
	 }
	 public double volume() {
	  return height*radius*radius*Math.PI;
	 }
	 public double surfaceArea() {
	  return 2*radius*Math.PI*(height+radius);
	  }
	 }