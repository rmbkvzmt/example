package Task2;

public abstract class Shapes {
public abstract double surfaceArea();
 
public abstract double volume();
}