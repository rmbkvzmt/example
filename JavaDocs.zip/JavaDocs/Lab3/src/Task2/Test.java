package Task2;

public class Test {

	public static void main(String[] args) {
		Cylinder cylinder = new Cylinder(7,9);
		Cube cube = new Cube(5,3,7);
		Sphere sphere = new Sphere(9);
		  
		System.out.println(cube.volume());
		System.out.println(cube.surfaceArea());
		System.out.println(cylinder.volume());
		System.out.println(cylinder.surfaceArea());
		System.out.println(sphere.volume());
		System.out.println(sphere.surfaceArea());
		
	}

}
