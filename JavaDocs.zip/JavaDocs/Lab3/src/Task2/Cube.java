package Task2;

public class Cube extends Shapes{
	 private double height;
	 private double width;
	 private double length;
	 public Cube(double height,double width,double length) {
	  this.height=height;
	  this.width=width;
	  this.length=length;
	  }
	  
	  public double volume() {
	   
	   return height*width*length;
	  }
	  public double surfaceArea() {
	   return 2*(length*height+length*width+width*height);
	  }
	 }
