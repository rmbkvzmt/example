package Task2;

public class Sphere extends Shapes{
	 private double radius;
	 
	 public Sphere(double radius) {
	 this.radius=radius;
	 }
	 
	 public double volume() {
	  return 4/3*Math.PI*radius*radius*radius;
	 }
	 public double surfaceArea() {
	  
	  return 4*Math.PI*radius*radius;
	  }
	 }