package Task5;

public class Student extends Person{
	private String program;
	private int year;
	private double fee;
	
	public Student(String name, String address,String program,int year,double fee) {
		super(name, address);
		this.fee = fee;
		this.year = year;
		this.program = program;
		
	}
	public String getProgram() {
		return program;
	}
	public void setProgram(String newProgram) {
		this.program = newProgram;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int newYear) {
		this.year = newYear;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double newFee) {
		this.fee = newFee;
	}
	public String toString() {
		return "Student name="+name+", address="+address+",program="+program+","+"year="+year+",fee="+fee;              
	}
	
	public boolean equals(Object o) {
		return false;
	}
	
	
}
