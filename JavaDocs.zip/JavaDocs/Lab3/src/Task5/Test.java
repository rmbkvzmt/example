package Task5;

import java.util.*;

public class Test {

	public static void main(String[] args) {
		Vector<Person> persons = new Vector<Person>();
		persons.add(new Student("Azamat","abc","DB",5,3.14));
		persons.add(new Student("Abylai","asd","ASD",5,3.14));
		persons.add(new Staff("Daulet","frt","KB",1500000));
		for(int i = 0; i < persons.size(); i++) {
			System.out.println(persons.get(i).toString());
		}

	}

}
