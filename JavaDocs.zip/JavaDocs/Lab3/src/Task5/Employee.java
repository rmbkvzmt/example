package Task5;


public class Employee extends Person{
	public double salary;
	public int year;
	public String insuranceNumber;
	
	public Employee() {
		super("A","B");
		this.salary = 0;
		this.year = 0;
		this.insuranceNumber = "C";
	}
	public Employee(String name) {
		super(name,"B");
		this.salary = 0;
	}
	public Employee(String name,String address) {
		super(name,address);
		this.salary = 0;
		this.year = 0;
		this.insuranceNumber = "";
	}
	public Employee(String name,String address,double salary) {
		super(name,address);
		this.salary = salary;
		this.year = 0;
		this.insuranceNumber = "";
	}
	public Employee(String name,String address,double salary,int year) {
		super(name,address);
		this.salary = salary;
		this.year = year;
		this.insuranceNumber = "";
	}
	public Employee(String name, String address,double salary,int year,String insuranceNumber) {
		super(name, address);
		this.salary = salary;
		this.year = year;
		this.insuranceNumber = insuranceNumber;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public double getSalary() {
		return salary;
	}
	public int getYear() {
		return year;
	}
	public String getInsuranceNumber() {
		return insuranceNumber;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public void setInsuranceNumber(String newInsuranceNumber) {
		this.insuranceNumber = newInsuranceNumber;
	}
	
	public boolean equals(Object o) {
		if(o==this) {
			return true;
		}
		if(!(o instanceof Employee)) {
			return false;
		}
		
		Employee e = (Employee)o;

		return e.name.equals(name) && e.address.equals(address) && e.salary==(salary) && e.year == year && e.insuranceNumber==insuranceNumber;
	}

	public String toString() {
		return null;
	}
	
}

