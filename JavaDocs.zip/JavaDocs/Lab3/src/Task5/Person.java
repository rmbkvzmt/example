package Task5;

public abstract class Person {
	protected String name;
	protected String address;
	public Person(String name,String address) {
		this.address = address;
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String newAddress) {
		this.address = newAddress;
	}
	
	public abstract boolean equals(Object o);
	
	public abstract String toString();
}
