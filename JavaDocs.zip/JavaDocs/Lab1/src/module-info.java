module Lab1 {
}