Map<Integer,Integer> cnts = new HashMap<Integer, Integer>();
    int array[] = new int[1000];

    for(int i=0;i<array.length;i++){
        for (Map.Entry<Integer, Integer> entry : cnts.entrySet()) {
            if(array[i]==entry.getKey()){
                int val = entry.getValue()+1; // increment value by 1
                entry.setValue(val);
            }
        }
    }