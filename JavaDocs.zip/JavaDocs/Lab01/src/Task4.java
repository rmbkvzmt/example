import java.util.Scanner;

public class Task4 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);	
		System.out.println("Parameter for a:");
		double a = input.nextDouble();			
		System.out.println("Parameter for b:");
		double b = input.nextDouble();	
		System.out.println("Parameter for c:");
		double c = input.nextDouble();	
		input.close();
		
		double root1;
		double root2;
		double root0;//here I forgot situation when determinant = 0
		double determinant = (b*b) - (4*a*c);//here I've had my first mistake when I forgot to use parentheses
		
		if (determinant > 0) {
			root1 = (-b - Math.sqrt(determinant))/(2*a);
			root2 = (-b + Math.sqrt(determinant))/(2*a);
			System.out.println("First root is equal to" + " " + root1 );
			System.out.println("Second root is equal to" + " " + root2 );
		} else if (determinant < 0) {
			System.out.println("Error message");
		} else if (determinant == 0) {
			root0 = (-b)/(2*a);
			System.out.println("The root is equal to" + " " + root0 );
	}

}}
