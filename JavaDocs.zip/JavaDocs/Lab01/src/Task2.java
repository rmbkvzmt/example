import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);		
		double side_a = input.nextDouble();		
		input.close();
		
		double area = side_a * side_a;
		double perimeter = side_a * 4;
		double length =  side_a * Math.sqrt(2);
		
		System.out.println("Area of the square is equal to" +" " + area);
		System.out.println("Perimeter of the square is equal to" + " " +  perimeter);
		System.out.println("Length of the square is equal to" +  " " +  length);
	}

}
