
public class Task1 {

	public static void main(String[] args) {
		System.out.println("+------+");
		System.out.println("|Azamat|");
		System.out.println("+------+");
	}
}
