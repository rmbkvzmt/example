import java.util.Scanner;

public class Task3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);		
		double grade = input.nextDouble();		
		input.close();
		
		if (grade >= 95) {
			System.out.println("Your GPA is" + " " + "A");
			} else if (grade >= 90) {
				System.out.println("Your GPA is" + " " + "A-");
			} else if (grade >= 85 && grade <= 89) {
				System.out.println("Your GPA is" + " " + "B+");
			}else if (grade >= 80 && grade <= 84) {
				System.out.println("Your GPA is" + " " + "B");
			}else if (grade >= 75 && grade <= 79) {
				System.out.println("Your GPA is" + " " + "B-");
			}else if (grade >= 70 && grade <= 74) {
				System.out.println("Your GPA is" + " " + "C+");
			}else if (grade >= 65 && grade <= 69) {
				System.out.println("Your GPA is" + " " + "C");
			}else if (grade >= 60 && grade <= 64) {
				System.out.println("Your GPA is" + " " + "C-");
			}else if (grade >= 55 && grade <= 59) {
				System.out.println("Your GPA is" + " " + "D+");
			}else if (grade >= 50 && grade <= 54) {
				System.out.println("Your GPA is" + " " + "D");
			}else if (grade <= 49) {
				System.out.println("Your GPA is" + " " + "F");
			}

}
}