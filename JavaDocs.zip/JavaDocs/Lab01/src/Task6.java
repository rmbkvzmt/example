import java.util.Scanner;

public class Task6 {
	static boolean palindrome(String str1) {
		String str, check = "";
		boolean isPalindrome;// Then I've had some troubles here for >30 min , cause I've forgotten to equal them to ""
		Scanner input = new Scanner(System.in);	
		System.out.println("Enter your string:");
		str = input.nextLine();
		input.close();
		
		
		for( int i = 0; str.length()-1 >=0; i--)
			check = check + str.charAt(i);
			
		if(str.equals(check)) {// I didn't how to write it like str = check(cause it's incorrect, so I've googled it)
			isPalindrome  = true;
		} else isPalindrome = false;
		return isPalindrome;
	}

	public static void main(String[] args) {
		palindrome("TRRT");		
}
}
