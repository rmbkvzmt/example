import java.util.Scanner;

public class Task5 {

	public static void main(String[] args) {
		double inBalance, perMonth, rateInt;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter your initial balance:");
		inBalance = input.nextDouble();
		System.out.println("Enter the period:");
		perMonth = input.nextDouble();
		System.out.println("Enter the rate of interest:");
		rateInt = input.nextDouble();
		input.close();
		
		double interest = (inBalance * perMonth * rateInt)/100;
		double total = inBalance + interest;
		
		System.out.println("Your interest:" + interest);
		System.out.println("Your total balance:" + total);
	}

}
