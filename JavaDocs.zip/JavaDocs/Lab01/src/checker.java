
public class checker {
	
	public static void check(String s1, String s2, String s3) 
	{
		boolean c = true;
		if (s1.equals(s2) || s1.equals(s3)) {
			c = false;
		} else if (s2.equals(s3) || s2.equals(s1)) {
			c = false;
		} else if (s3.equals(s1) || s3.equals(s2)) {
			c = false;
		}
		
		System.out.println(c);
	}

	public static void main(String[] args) {
		String a = "Azamat";
		String b = "Dulat";
		String c = "Azamat";
		check(a,b,c);

	}

}
