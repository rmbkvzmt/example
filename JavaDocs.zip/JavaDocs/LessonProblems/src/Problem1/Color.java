package Problem1;

public enum Color {
	RED,BLACK
}
