package Problem1;

import Problem1.*;
import java.util.Vector;


public abstract class Shape 
{
	public Color color;

	public Shape(Color color)
	{
	  this.color=color;
	}
	public abstract void draw();
	  
	public void draw(int cnt) {
	    for(int i=0; i<3; i++)
	    	draw();
	  }


	public static void main(String[] args) {
		Circle circle1 = new Circle(Color.BLACK);
		Rectangle rectangle1 = new Rectangle(Color.RED);
	    Vector<Shape> shapes = new Vector<Shape>();
	    shapes.add(circle1);
	    shapes.add(rectangle1);
	    for(Shape shape : shapes) {
	      shape.draw();
	    }
}
	}
