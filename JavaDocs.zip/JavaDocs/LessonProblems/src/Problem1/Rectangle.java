package Problem1;

public class Rectangle extends Shape {
	public Rectangle(Color color) {
	    super(color);
	}
	public void draw() {
		if(color==color.BLACK)
	      System.out.println(" --\n|  |\n --");
	    else
	      System.err.println(" --\n|  |\n --");
	  }
	}