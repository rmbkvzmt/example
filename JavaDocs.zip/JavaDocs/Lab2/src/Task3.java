import java.util.Scanner;

class Data{
  double max;
    double sum;
    static int n;

    public Data()
    {
      max=0;
      sum=0;
      n=0;
    }
    public void add(int a)
    {
      sum+=a;
      n++;
      if (max<=a && a>0) max=a;
    }
    public double getMax()
    {
      return max;
    }
    public double getAvrg()
    {
      if (n==0) return 0;
      return sum/n;
    }
}
class Analyzer{
  Data data = new Data();
  
  public void addValues(){
  Scanner input = new Scanner(System.in);
  System.out.println("Enter number(Q to quit): ");
  while(input.hasNext()){
    System.out.println("Enter number(Q to quit): ");
    String str = input.next();
    if(str.equals("Q") || str.equals("q"))
    {
      System.out.println("Average = "+ data.getAvrg());
      System.out.println("Maximum = "+ data.getMax());
      break;
      }
    data.add(Integer.parseInt(str));
    }
  input.close();
  }
}
public class Task3 {
  
      public static void main(String[] args)
      {
        Analyzer a = new Analyzer();
        a.addValues();
      }   
}