
public class Time {
	public int hours;
	public int minutes;
	public int seconds;
	
	public Time(int hours, int minutes, int seconds)
	  {
	    this.hours = hours;
	    this.minutes = minutes;
	    this.seconds = seconds;
	  }
	
	public String toUniversal()
	  {
	    String str = "";
	    if(hours <= 24 && minutes < 60 && minutes > 9 && seconds < 60 && seconds > 9)
	    {
	      str = (hours + ":" + minutes + ":" + seconds);
	    }
	    else if(hours <= 24 && minutes <= 9 && minutes >= 0 && seconds <=9 && seconds >= 0)
	    {
	      str = (hours + ":0" + minutes + ":0" + seconds);
	    }
	    else str ="Invalid";
	    return str;
	  }
	  
	  public String toStandard()
	  {
	    String str = "";
	    if(hours <= 24 && hours > 12 && minutes < 60 && minutes > 9 && seconds < 60 && seconds > 9)
	    {
	      str = (hours-12 + ":" + minutes + ":" + seconds + " PM");
	    }
	    else if(hours <= 24 && hours > 12 && minutes <= 9 && minutes >= 0 && seconds >= 0 && seconds <= 9)
	    {
	      str = (hours-12 + ":0" + minutes + ":0" + seconds + " PM");
	    }
	    else if(hours <= 12 &&  minutes < 60 && minutes > 9 && seconds < 60 && seconds > 9)
	    {
	      str = (hours + ":" + minutes + ":" + seconds + " AM");
	    }
	    else if(hours <= 12 &&  minutes <= 9 && minutes >= 0 && seconds >= 0 && seconds <= 9)
	    {
	      str = (hours + ":0" + minutes + ":0" + seconds + " AM");
	    }
	    else str = "Invalid";
	    return str;
	  }
	  
	  public static Time add(Time t, Time t2)
	  {
	    return new Time(t.hours + t2.hours, t.minutes + t2.minutes, t.seconds + t2.seconds);    
	  }

	public static void main(String[] args) {
		 Time t = new Time(24,0,0);
		    System.out.println("Universal: "+ t.toUniversal());
		    System.out.println("Standard: "+ t.toStandard());

	}

}
