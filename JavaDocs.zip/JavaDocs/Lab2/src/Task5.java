enum TrafficLight {
	RED(120,2), YELLOW(60, 1), GREEN(180, 3);
	
	private final int seconds;
	private final int minutes;
	char empty = ' ';
	TrafficLight(int seconds, int minutes) 
	{
		this.seconds = seconds;
		this.minutes = minutes;
	}
	int getSeconds()
	{
		return seconds;
	}
	
	int getMinutes()
	{
		return minutes;
	}
	static
	{
		System.out.println("Time:");
	}
	
	public void printTime(TrafficLight light) 
	{
		System.out.printf("%s: %d seconds\n", light, light.getSeconds() );
	}
	
	public void printTime(TrafficLight light1, char empty) 
	{
		System.out.printf("%s: %d minutes\n" + ' ', light1, light1.getMinutes() );
	}
}
public class Task5 {
	public static void main(String[] args) {
		for (TrafficLight light : TrafficLight.values()) {
			light.printTime(light);
			light.printTime(light,' ');
      }
   }
}