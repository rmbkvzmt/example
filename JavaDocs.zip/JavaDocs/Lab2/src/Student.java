public class Student {
	
		private String name;
		private String id;
		private int yearOfStudy;
		Student(String name, String id, int yearOfStudy)
		{
			this.name = name;
			this.id = id;
			this.yearOfStudy = yearOfStudy;
		}
		
		public String getName() 
		{
			return name;
		}
		
		public void setName(String name) 
		{
			this.name = name;
		}
		
		public String getId() 
		{
			return id;
		}
		
		public void setId(String id) 
		{
			this.id = id;
		}
		
		public int getYearOfStudy() 
		{
			return yearOfStudy;
		}
		
		public void setYearOfStudy(int yearOfStudy) 
		{
			this.yearOfStudy = yearOfStudy;
		}
		
		private static String access(Student st) 
		{
			return st.getName() + " " + st.getId() + " " + st.getYearOfStudy();
		}
		
	public static void main(String[] args) {
		Student stu = new Student("Azamat","18BD110394",2);
		System.out.println(access(stu));;
	}

}
