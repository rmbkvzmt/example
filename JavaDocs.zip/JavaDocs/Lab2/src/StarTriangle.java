import java.util.Scanner;

public class StarTriangle {
	/*
	 * StarTriangle(int width){ for (int i = 1; i<= width; i++) { for (int j = 0;
	 * j<i; j++) { System.out.print("[*]"); } System.out.println(""); } }
	 */
	private String str = "";
	private int width;
	StarTriangle(int width)
	{
		this.width = width;
	}
	
	public String ToString() 
	{
		String[][] arr = new String[width][width];
		for(int i =1; i < width; i++) 
		{
			for (int j = 0; j < i; j++)
			{
				arr[i][j] = ("[*]");
				str += arr[i][j];
			} str += "\n";
		} return str;
	}
	
	public int getWidth() 
	{
		return width;
	}
	
	public void setWidth(int width) 
	{
		this.width = width;
	}
	
	public static void main(String[] args) {
		/*
		 * Scanner input = new Scanner(System.in); int width = input.nextInt();
		 * StarTriangle small = new StarTriangle(width); input.close();
		 * System.out.println(small.toString());
		 */
		Scanner input = new Scanner(System.in);
		int result = input.nextInt();
		StarTriangle small = new StarTriangle(result+1);
	    System.out.println(small);
	    input.close();
	}

}
