CREATE database lab4;

CREATE TABLE Warehouses(
    Code integer,
    Location varchar(255),
    Capacity integer
);

INSERT INTO Warehouses(Code,Location,Capacity) VALUES(1,'Chicago',3);
 INSERT INTO Warehouses(Code,Location,Capacity) VALUES(2,'Chicago',4);
 INSERT INTO Warehouses(Code,Location,Capacity) VALUES(3,'New York',7);
 INSERT INTO Warehouses(Code,Location,Capacity) VALUES(4,'Los Angeles',2);
 INSERT INTO Warehouses(Code,Location,Capacity) VALUES(5,'San Francisco',8);

CREATE TABLE Boxes(
    Code Varchar(4),
    Contents Varchar(255),
    Value integer,
    Warehouse integer
);

 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('0MN7','Rocks',180,3);
 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('4H8P','Rocks',250,1);
 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('4RT3','Scissors',190,4);
 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('7G3H','Rocks',200,1);
 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('8JN6','Papers',75,1);
 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('8Y6U','Papers',50,3);
 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('9J6F','Papers',175,2);
 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('LL08','Rocks',140,4);
 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('P0H6','Scissors',125,1);
 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('P2T6','Scissors',150,2);
 INSERT INTO Boxes(Code,Contents,Value,Warehouse) VALUES('TU55','Papers',90,5);

SELECT * from Warehouses;
SELECT * from Boxes;

Select * FROM Warehouses WHERE Location='Chicago';

SELECT warehouse FROM Boxes group by warehouse;

SELECT Value from Boxes where Value > 140 and Value <=200;

select distinct sum(Warehouse) from Boxes;

select distinct Warehouse from Boxes where Contents = 'Rocks' and Value < 220;

update Boxes set Value = Value + Value * 0.2 from Warehouses
where Boxes.Warehouse = Warehouses.Code and (Warehouses.Location = 'San Francisco' or Warehouses.Location = 'New York')
      returning  Boxes.Code, Value;

update Boxes set Value = Value/2 where Value % 2 = 0
                                       returning  Boxes.Code, Value;
update Boxes set Value = Value/5 from Warehouses
where Boxes.Warehouse = Warehouses.Code and (Value % 2 != 0 and Warehouses.Location = 'Chicago')
      returning  Boxes.Code, Value;

select Code from Boxes where Boxes.Warehouse in (select Code from Warehouses where Location like '%o' and Capacity > 3) ;

select distinct Contents from Boxes;

select Code from Boxes where Warehouse not in (select Code from Warehouses where Location = 'Chicago')
order by Value desc limit 1 offset 1;

select Code from Boxes where Value % 3 = 0 order by Value limit 1 offset 2;

select Contents, sum(Value) as total_value from Boxes group by contents;

-- select distinct Warehouse, sum(Value) as total_value from Boxes
-- group by warehouse union select distinct code, Location from Warehouses;

select distinct Boxes.Warehouse, Warehouses.Location, sum(Value) as total from Boxes
    inner join Warehouses on Boxes.Warehouse = Warehouses.Code group by Boxes.Warehouse, Warehouses.Location order by Warehouse;