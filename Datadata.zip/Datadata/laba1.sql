create database lab1;

CREATE TABLE users(
    id serial,
    first_name varchar(50),
    last_name varchar(50)
);

ALTER TABLE users
    ADD COLUMN is_admin integer ;

ALTER TABLE users
alter column is_admin drop default ;

alter table  users
alter is_admin type bool using users.is_admin::boolean;

alter table users
alter column is_admin set default false;

alter table users
add constraint person primary key(id);