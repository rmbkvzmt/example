create database l1;

CREATE TABLE users2(
    id serial,
    first_name varchar(50),
    last_name varchar(50)
);

ALTER TABLE users2
    ADD COLUMN is_admin2 integer ;

ALTER TABLE users2
alter column is_admin2 drop default ;

alter table  users2
alter is_admin2 type bool using users2.is_admin2::boolean;

alter table users2
alter column is_admin2 set default false;

alter table users2
add primary key(id);

create table tasks2(
    id serial,
    name varchar(50),
    user_id integer
);

drop table tasks2 cascade ;

drop database l1 ;