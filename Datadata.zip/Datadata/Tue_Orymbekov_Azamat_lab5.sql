CREATE database lab5;

CREATE TABLE customers(
    customer_id integer,
    cust_name varchar(255),
    city varchar(255),
    grade integer,
    salesman_id integer
);
CREATE TABLE orders(
    ord_no integer,
    purch_amt float,
    ord_date timestamp,
    customer_id integer,
    salesman_id integer
);
insert into customers values (3002,'Nick Rimando', 'New York', 100, 5001),
                             (3005, 'Graham Zusi', 'California', 200, 5002),
                             (3001, 'Brad Guzan', 'London', null , 5005),
                             (3004, 'Fabian Johns', 'Paris', 300, 5006),
                             (3007,'Brad Davis', 'New York', 200, 5001),
                             (3009, 'Geoff Camero', 'Berlin', 100, 5003),
                             (3008, 'Julian Green','London', 300, 5002 );
select * from customers;

insert into orders values (70001, 150.5, '2012-10-05', 3005, 5002),
                          (70009, 270.65, '2012-09-10', 3001, 5005),
                          (70002, 65.26, '2012-10-05', 3002, 5001),
                          (70004, 110.5, '2012-08-17', 3009, 5003),
                          (70007, 948.5, '2012-09-10', 3005, 5002),
                          (70005, 2400.6, '2012-07-27', 3007, 5001),
                          (70008, 5760, '2012-09-10', 3002, 5001);

select * from orders;

select sum(purch_amt) as total_purch from orders;

select avg(purch_amt) as avg_purch from orders;

select count(cust_name) from customers;

select min(purch_amt) as min_purch from orders;

select cust_name from customers where cust_name like '%n';

select ord_no from orders where customer_id in (select customer_id from customers where city = 'New York');

select cust_name from customers where customer_id in (select customer_id from orders where purch_amt > 200);

select sum(grade) from customers;

select cust_name from customers;

select max(grade) from customers;

select count(all grade) from customers;

select count(distinct salesman_id) from orders;
select count(distinct salesman_id) from customers;

select city, max(grade) as max from customers group by city order by max desc;

/*update customers set grade = grade + grade * 0.2 where customer_id in
(select customer_id, avg(purch_amt) as avg_pa from orders group by customer_id having orders.customer_id = customers.customer_id)
returning customers.customer_id,customers.cust_name, grade;*/

select orders.customer_id, customers.cust_name, customers.grade * 1.2 as new_grade, avg(purch_amt) as avg_purch
from customers inner join orders on customers.customer_id = orders.customer_id
group by orders.customer_id, customers.cust_name, new_grade order by customer_id;