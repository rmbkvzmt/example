create table new_category
(
  category_id serial primary key,
  name        varchar(25),
  last_update timestamp
);

select *
from new_category;

insert into new_category (name, last_update)
values ('Category 1', now());

insert into new_category (name, last_update)
values ('Category 2', now()) returning *;

insert into new_category (name, last_update)
values ('Category 2', now()) returning category_id;

alter table new_category
  alter column category_id set default 0;

alter table new_category
  alter column name set default 'Some name';

alter table new_category
  alter column last_update set default now();

insert into new_category default
values;

insert into new_category
values (default, default, now());

delete
from new_category;

insert into new_category
select *
from category
where category_id < 10 returning *;

alter sequence new_category_category_id_seq increment by 4;


update new_category
set name='Dramatic'
where name = 'Drama' returning *;


update new_category
set name=name || ' category';

alter table new_category
  alter column name set default 'Horror';

update new_category
set name = DEFAULT
where category_id = 5;

select *
from new_category;

update new_category
set name='Comedy'
from category
where new_category.category_id = category.category_id;


update new_category
set (name, last_update)=(select name, last_update from category where category_id = 10)
where name = 'Travel';


delete
from new_category as n using category as c
where n.category_id = c.category_id returning n.name as category_name;

delete
from new_category
where category_id IN (select category_id from category);

alter table new_category
add column "Is_Active" boolean;

select NAME from new_category;