package Task4;

public interface Comparable<E> {
	public int[] minmax(int values[]);
	
}
