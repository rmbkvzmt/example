package Task4;

public class MinMax implements Comparable<MinMax>{

	@Override
	public int[] minmax(int[] values) {
		// TODO Auto-generated method stub
		int minmax[] = new int[2];
		
		
		
		return minmax;
	}
	
	
}
