CREATE DATABASE lab9;

CREATE TABLE salesman (
    salesman_id serial primary key ,
    name varchar(50),
    city varchar(50),
    commission float
);
CREATE TABLE customers (
    customer_id serial primary key ,
    cust_name varchar(50),
    city varchar(50),
    grade int,
    salesman_id int REFERENCES salesman
);

CREATE TABLE  orders (
     ord_no serial,
     purch_amt float,
     ord_date timestamp,
     customer_id int REFERENCES customers,
     salesman_id int REFERENCES salesman
);

CREATE ROLE junior_dev WITH LOGIN PASSWORD '774765';

CREATE VIEW salesman_ord AS SELECT name, AVG(purch_amt), SUM(purch_amt)
FROM salesman, orders
WHERE salesman.salesman_id = orders.salesman_id GROUP BY name;

CREATE VIEW city_num AS SELECT city, COUNT(DISTINCT orders.customer_id)
FROM customers, orders
WHERE orders.customer_id = customers.customer_id
GROUP BY city;

GRANT ALL PRIVILEGES ON city_num TO junior_dev;

CREATE VIEW low_grade AS SELECT * FROM customers
WHERE grade = (SELECT MIN(grade) FROM customers);

GRANT SELECT ON low_grade TO junior_dev;

CREATE VIEW salesman_num AS SELECT grade, COUNT(DISTINCT salesman_id)
FROM customers GROUP BY grade;

CREATE VIEW salesman_2 AS SELECT * FROM salesman
WHERE 1 < (SELECT COUNT(DISTINCT *) FROM orders WHERE salesman.salesman_id = orders.salesman_id);

CREATE ROLE intern WITH LOGIN PASSWORD '87557';
GRANT junior_dev TO intern;