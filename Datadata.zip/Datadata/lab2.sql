create database lab2;

create table project
(
    id serial,
    name_p varchar(50),
    start_datetime timestamp,
    end_datetime timestamp,
    is_finished boolean,
    description text
);

alter table project
    add column created_at timestamp;

alter table project
    alter column name_p set data type varchar(100);

alter table project
    alter column is_finished set default false;

alter table project
add primary key(id);

create table tasks (
    id serial,
    name varchar(50),
    description text,
    priority smallint,
    project_id serial,
    foreign key (project_id) references project(id)
);

drop table project ;
drop table project cascade ;
drop database lab1;