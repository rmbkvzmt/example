create database mid;

create table worker(
    worker_id serial,
    first_name varchar,
    last_name varchar,
    salary integer,
    joining_date timestamp,
    department varchar
);

insert into worker values (default, 'Monika', 'Arora', 100000, '2014-02-20 09:00:00', 'HR'),
                          (default, 'Niharika', 'Verma', 80000, '2014-06-11 09:00:00', 'Admin'),
                          (default, 'Vishal', 'Singhal', 300000, '2014-02-20 09:00:00', 'HR'),
                          (default, 'Amitabh', 'Singh', 500000, '2014-02-20 09:00:00', 'Admin'),
                          (default, 'Vivek', 'Bhati', 500000, '2014-06-11 09:00:00', 'Admin'),
                          (default, 'Vipul', 'Diwan', 200000, '2014-06-11 09:00:00', 'Account'),
                          (default, 'Satish', 'Kumar', 75000, '2014-01-20 09:00:00', 'Account'),
                          (default, 'Geetika', 'Chauhan', 90000, '2014-04-11 09:00:00', 'Admin');

-- select first_name, last_name, department from (select max(salary), department from worker group by department)
--     as new inner join worker on new.department = worker.department

select first_name, last_name, department, salary from worker
where (department, salary) in (select department, max(salary) from worker group by department);