CREATE DATABASE sales;

CREATE TABLE films
(
  id        serial primary key,
  code_var  varchar(5),
  code_char char(5),
  name      varchar(10) not null,
  genre_id integer references genres(id)
);


ALTER TABLE films
  ADD COLUMN rating integer;

ALTER TABLE films
  ALTER COLUMN code_var SET NOT NULL;

ALTER TABLE films
  ALTER COLUMN name DROP NOT NULL;

ALTER TABLE films
  ADD UNIQUE (rating);

insert into films
values (default, 'abc', 'abc', NULL);

insert into films
values (default, 'abc', 'abc', 'Other Name');

insert into films
values (default, 'abc', 'abc', 'Other Name', 1);

insert into films
values (default, 'abc', 'abc', 'Other Name', NULL);

UPDATE films SET rating=2 WHERE id=1;

select *
from films;


CREATE TABLE genres (
  id serial primary key,
  name varchar(100)
);

select * from genres;

ALTER TABLE films
  ADD COLUMN genre_id integer references genres(id);

insert into genres values
  (default, 'comedy'),
  (default, 'drama');

update films set genre_id=1 where id=5;
update films set genre_id=3 where id=1;

drop table films cascade;


select * from pg_constraint;