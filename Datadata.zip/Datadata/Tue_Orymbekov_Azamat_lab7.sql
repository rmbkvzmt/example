CREATE DATABASE lab7;

CREATE TABLE locations (
    location_id SERIAL PRIMARY KEY,
    street_address varchar(25),
    postal_code varchar(12),
    city varchar(30),
    state_province varchar(12)
);

INSERT INTO locations VALUES (101, '2017 Shinjuku-ku', 'AB1689', 'Tokyo', 'Prefecture'),
                             (102, '2014 Jabberwocky Rd', 'AB26192', 'Southlake', 'Texas'),
                             (103, '2011 Interiors Blvd', 'AB99236', 'South San Francisco', 'California'),
                             (104, '2007 Zagora St', 'AB50096', 'South Brunswick', 'New Jersey');

CREATE TABLE departments (
    department_id SERIAL PRIMARY KEY,
    department_name varchar(50) UNIQUE,
    budget integer,
    location_id integer REFERENCES locations
);

INSERT INTO departments VALUES (1001, 'Administration', 100000, 101),
                               (1002, 'Marketing', 200000, 102),
                               (1003, 'Purchasing', 300000, 103),
                               (1004, 'IT', 400000, 104);

CREATE TABLE employees (
    employee_id SERIAL PRIMARY KEY,
    first_name varchar(50),
    last_name varchar(50),
    email varchar(50),
    phone_number varchar(50),
    salary INTEGER,
    manager_id integer REFERENCES managers,
    department_id INTEGER REFERENCES departments
);

INSERT INTO employees VALUES (1, 'Steven', 'King', 'sking@gmail.com', '515.123.4567', 10000, 3001, 1001),
                             (2, 'Higgins', 'Taylor', 'taylor@gmail.com', '650.124.1334', 15000, 3002, 1002),
                             (3, 'Jason', 'Taylor', 'jason@gmail.com', '011.44.1345.929268', 20000, 3003, 1003),
                             (4, 'Oliver', 'Pataballa', 'pataballa@gmail.com', '590.423.5567', 25000, 3004, 1004);

drop table employees;

INSERT INTO managers VALUES (3001, 'Steven', 'Bissot'),
                            (3002, 'Higgins', 'Taylor'),
                            (3003, 'Jason', 'Taylor'),
                            (3004, 'Oliver', 'Pataballa');

CREATE TABLE managers (
    manager_id SERIAL PRIMARY KEY,
    first_name varchar(50),
    last_name varchar(50)
);

CREATE TABLE job_grades(
    grade char(1),
    lowest_salary INTEGER,
    highest_salary INTEGER
);

INSERT INTO job_grades VALUES ('A', 1000, 2999),
                              ('B', 3000, 5999),
                              ('C', 6000, 9999),
                              ('D', 10000, 14999);
--3
SELECT employees.first_name, employees.last_name, employees.department_id, locations.city, locations.state_province, departments.department_name
    FROM employees INNER JOIN departments ON employees.department_id = departments.department_id
        INNER JOIN locations ON departments.location_id = locations.location_id
WHERE last_name LIKE '%b%';
--4
SELECT departments.department_name, locations.city, locations.state_province FROM departments
    INNER JOIN locations ON departments.location_id = locations.location_id ORDER BY department_name;
--5
SELECT employees.first_name , managers.first_name FROM employees LEFT JOIN managers ON employees.manager_id = managers.manager_id;
--6
SELECT employees.first_name, employees.last_name, employees.salary, job_grades.grade
 FROM employees JOIN job_grades
     ON employees.salary BETWEEN job_grades.lowest_salary AND job_grades.highest_salary;
--7
UPDATE locations set city = 'London' where city = 'Tokyo';
SELECT employees.first_name, employees.last_name, employees.salary from employees
    JOIN departments USING (department_id) JOIN locations USING (location_id)
WHERE city = 'London';
--8
SELECT employees.first_name, employees.last_name, employees.department_id, departments.department_name FROM employees
JOIN departments ON employees.department_id = departments.department_id order by first_name;
--9
SELECT employees.first_name , employees.last_name , employees.department_id , departments.department_name
         FROM employees JOIN departments ON employees.department_id = departments.department_id
          AND employees.department_id IN (80 , 40) ORDER BY employees.last_name;
--10
SELECT A.first_name, A.last_name, A.department_id FROM employees A JOIN employees B
     ON A.department_id = B.department_id
       AND B.last_name = 'Jing';

INSERT INTO employees VALUES (5, 'Stephen', 'Jing', 'sking@gmail.com', '515.123.4567', 10000, 3001, 1002),
                             (6, 'Higgy', 'Tulor', 'taylor@gmail.com', '650.124.1334', 15000, 3002, 1002);

SELECT A.first_name, A.last_name, A.department_id FROM employees A JOIN departments B
     ON A.department_id = B.department_id
     where B.department_id= (select department_id from employees where last_name = 'Jing');
select * from employees;

