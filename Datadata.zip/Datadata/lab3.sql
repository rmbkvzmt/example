CREATE DATABASE lab3;

CREATE TABLE  computers
(
    comp_id serial primary key,
    name_comp varchar(10),
    model varchar,
    speed integer,

);