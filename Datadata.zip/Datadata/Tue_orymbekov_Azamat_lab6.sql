CREATE DATABASE lab6;

CREATE TABLE employees (
    emp_id serial PRIMARY KEY ,
    first_name varchar(20),
    last_name varchar(40),
    salary integer NOT NULL,
    begin_date timestamp,
    end_date timestamp,
    job_title varchar(50) default 'blank'
);

CREATE TABLE department (
    department_id serial PRIMARY KEY NOT NULL,
    emp_id serial REFERENCES employees(emp_id),
    department_name varchar(5),
    email varchar(40) UNIQUE,
    phone_number varchar(12),
    hire_date timestamp without time zone,
    commission float
);

ALTER TABLE employees ADD CHECK ( end_date >= begin_date AND begin_date >= '2000-01-01');

ALTER TABLE employees ADD CONSTRAINT chk_salary CHECK ( salary > 65000 );

ALTER TABLE employees ADD CONSTRAINT uniq_ln UNIQUE (last_name);

ALTER TABLE employees DROP CONSTRAINT chk_salary;

SELECT first_name, last_name FROM employees WHERE emp_id = (SELECT emp_id from department);

ALTER TABLE department ADD CHECK ( department.department_name = 'FIT' OR department.department_name = 'BS'
                OR department.department_name = 'FEOG' OR department.department_name = 'FGGE');

ALTER TABLE employees DROP COLUMN emp_id CASCADE;

SELECT first_name, last_name from employees ORDER BY last_name = 'Fleming', last_name ;

ALTER TABLE employees DROP CONSTRAINT uniq_ln;




