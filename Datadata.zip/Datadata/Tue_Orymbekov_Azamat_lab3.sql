CREATE DATABASE lab_3;

CREATE TABLE countries
(
    column_id serial primary key,
    country_name varchar,
    region_id integer,
    population integer
);

insert into countries values (default, 'Russia', 143, 8890335);

insert into countries values (default, 'Armenia', default , default);

alter table countries
alter column region_id  set default null;

insert into countries values (default, 'Afghanistan',null,38041754),
                             (default, 'Algeria',69 , 43053054),
                             (default, 'Angola',72 , 31825295);
insert into countries (country_name, population) values ('kasas',900000);

alter table countries
  alter column country_name set default 'Kazakhstan';

insert into countries default values;

create table countries_new (LIKE countries);

INSERT INTO countries_new SELECT * FROM countries;

UPDATE countries set region_id = 1 where region_id is null;

update countries set population = population + (population * 0.1)
                     returning country_name, population as new_population;

delete from countries where population < 20000000;

select * from countries;

delete from countries_new where column_id in ( select column_id from countries) returning *;

delete from countries returning *;















