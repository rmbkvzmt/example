create index ix_hgg on salesman (salesman_id,city);
drop index ix_hgg;

create view abc as select count(purch_amt) from salesman group by customer_id;

create view asd as select c.cust_name, s.name from salesman s
join customer c on customer.salesman_id = salesman.salesman_id where salesman.city <> customer.city;