create database Lab82;

create table employee(
    emp_id integer primary key,
    emp_name varchar(20),
    job_name varchar(20),
    manager_id integer references Employee(emp_id),
    hire_date timestamp,
    salary double precision,
    commission double precision,
    dep_id integer
);

INSERT INTO employee VALUES(1,'BLAZE','MANAGER', 68319, '1991-12-08', 2750.0, NULL, 3001);

select * from employee;

create index employees_name_index on Employee(emp_name);

create index employees_name_job_index on Employee(emp_name, job_name);

create unique index  employees_unique_index on Employee using btree (salary);

create index employees_order1_index on Employee(emp_id asc nulls first);

create index employees_order2_index on Employee(emp_id desc nulls last);

create unique index employees_unique103_index on Employee(dep_id);

create index employees_multi_index on Employee(emp_id, emp_name, job_name, manager_id, hire_date, salary, commission, dep_id);

create index employees_explain_index on Employee(manager_id);

explain SELECT * FROM employee WHERE emp_name = 'BLAZE' AND job_name = 'MANAGER';

drop index employees_unique103_index;



