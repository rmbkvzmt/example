select * from film;


select title, length from film where length between 90 and 60;

select title, length from film where length not between 60 and 90;

select 10 is distinct from 10.0;

select 10 is distinct from '10';

select ceil(4.345),
       floor(4.345),
       round(4.345),
       round(4.344, 2),
       trunc(4.345),
       trunc(4.345, 2),
       random();


select title || ' ' || length || ' ' || special_features from film;

select max(char_length(title)) from film;

select title, trim(both from title, 'Al') from film;

select title, overlay(title placing 'asd' from 2 for 5) from film;


select format('Title is: %s %s', title, description) from film;

select title from film where title like '__c%a';

select title,
       char_length(title),
       CASE
         when char_length(title) < 10 then 'Short title'
         when char_length(title) between 10 and 15 then 'Medium title'
         else 'Long title'
         end as "Title length"
from film;

select title from film where exists(select * from film where char_length(title) > 30);

select title from film where film_id in (select film_id from film_category  where category_id > 10);

select film_id, title from film where film_id > all (select film_id from film_category where category_id > 10);


select max(film_id) from film_category where category_id > 10;

select to_number('-123,123,454.8', 'S999G999G999D9');

select coalesce(title, description, 'default text') from film;



