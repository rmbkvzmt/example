package Task1;

public class Npc implements Moveable{
	
	@Override
	public void moveBackward() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void moveForward() {
		// TODO Auto-generated method stub
		
	}

}
