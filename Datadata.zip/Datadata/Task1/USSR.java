package Task1;

public interface USSR {
	String phoneCode = "123";
	
	String kazakh = "Kazakh";
	String russian = "Russian";
	String others = "others";
	
	void setNation(String nation);
	String getNation();
	
	
}
