package Task1;

public class YoungGeneration implements Kazakhstan{
	public int age;
	public String bank;
	public String iin;
	public String nation;
	
	public YoungGeneration(int age,String bank,String iin,String nation) {
		this.age = age;
		this.bank = bank;
		this.iin = iin;
		this.nation = nation;
	}

	@Override
	public void setNation(String nation) {
		// TODO Auto-generated method stub
		this.nation = nation;
	}

	@Override
	public String getNation() {
		// TODO Auto-generated method stub
		return nation;
	}
}
