package Task1;

public interface Kazakhstan {
	String phoneCode = "777";
	
	String kazakh = "Kazakh";
	String russian = "Russian";
	String others = "others";
	
	void setNation(String nation);
	String getNation();
	
}
