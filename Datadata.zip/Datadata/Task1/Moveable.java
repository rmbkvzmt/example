package Task1;

public interface Moveable extends MoveBack,MoveForward{
	
}
