package Task1;

public interface MoveBack {
	public void moveBackward();
}
