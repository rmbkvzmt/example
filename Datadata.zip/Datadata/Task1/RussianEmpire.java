package Task1;

public interface RussianEmpire {
	String phoneCode = null;
	
	String kazakh = "Kazakh";
	String russian = "Russian";
	String others = "others";
	
	void setNation(String nation);
	String getNation();
	
}
