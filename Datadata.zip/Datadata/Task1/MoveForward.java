package Task1;

public interface MoveForward {
	public void moveForward();
}
