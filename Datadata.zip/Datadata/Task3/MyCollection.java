package Task3;

public interface MyCollection<E> {
	
	MyCollection<E> orderData(MyCollection<E> e);
	
	MyCollection<E> deleteDuplicate(MyCollection<E> e);
	
}
