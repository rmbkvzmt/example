select * from film;


select lower(title) as "Title in lowercase", upper(title) as "Title in uppercase" from film;


select 10 + 5 as sum, 5 * 10 + 5 as sum_and_product;


select distinct on (length, rental_duration) title, length, rental_duration from film;


select * from film where length > 100  and (rental_duration > 5 and rental_duration <7);

select * from film;

select rental_duration,
       sum(length),
       count(*),
       max(length),
       min(length),
       avg(length)
from film group by rental_duration;


select * from film
where length > 100 and ( rental_duration > 5 or rental_duration < 7);


select * from film where length > 100 intersect
select * from film where ( rental_duration > 5 or rental_duration < 7);


select * from film where length > 100 or ( rental_duration > 5 or rental_duration < 7);


select * from film where length > 100 union select * from film where ( rental_duration > 5 or rental_duration < 7);

select * from film where length > 100 and not ( rental_duration > 5 and rental_duration < 7);

select * from film where length > 100 except select * from film where ( rental_duration > 5 or rental_duration < 7);

select * from film where length > 100 except select * from film where ( rental_duration > 5 and rental_duration < 7) order by length limit 10;

select * from film order by length desc, rental_duration asc, rental_rate asc;

select distinct on (length)* from film order by length desc nulls last limit 1 offset 2;






