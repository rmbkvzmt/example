create database laba1;

CREATE TABLE users1(
    id serial,
    first_name varchar(50),
    last_name varchar(50)
);

ALTER TABLE users1
    ADD COLUMN is_admin1 integer not null ;

update users1 set is_admin1 = 1;

ALTER TABLE users1
alter column is_admin1 drop default ;

alter table  users1
alter is_admin1 type boolean using users1.is_admin1::boolean;

alter table users1
alter column is_admin1 set default false;

alter table users1
add primary key(id);

create table tasks(
    id serial,
    name varchar(50),
    user_id integer
);

drop table tasks cascade ;

drop database laba1 ;