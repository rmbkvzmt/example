package Task2;

public interface Comparable<E> {
	public int compareTo(Object o);
}
