package Task2;

import java.util.Calendar;
import java.util.Vector;

public class Manager extends Employee implements Comparable<Employee>{
	
	public int bonus;
	public Vector<Employee> manager;
	public Manager(String name, String address, double salary, Calendar hireDate, String insuranceNumber,int bonus,Vector<Employee> manager) {
		super(name, address, salary, hireDate, insuranceNumber);
		this.bonus = bonus;
		this.manager = manager;
		// TODO Auto-generated constructor stub
	}
	
	public int getBonus() {
		return bonus;
	}
	
	public String toString() {
		String result = "";
		for(int i = 0 ; i < manager.size(); i++) {
			result += manager.get(i).toString() + "\n";
		}
		return result;
	}
	
	public int hashCode() {
		int result = 0;
		for(int i = 0; i < manager.size(); i++){
			result += manager.get(i).hashCode() + bonus;
		}
		return result;
	}
	
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		Manager other = (Manager) o;
		if(salary < other.salary) return -1;
		if(salary > other.salary) return 1;
		else {
			if(bonus < other.bonus) return -1;
			if(bonus > other.bonus) return 1;
			else return 0;
		}
	}
	
}
