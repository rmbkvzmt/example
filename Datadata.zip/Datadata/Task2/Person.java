package Task2;

public abstract class Person {
	String name,address;
	public Person(String name,String address) {
		this.name = name;
		this.address = address;
	}
	public abstract String toString();
}
