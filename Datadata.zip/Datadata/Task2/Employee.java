package Task2;

import java.util.Calendar;;

public class Employee extends Person implements Comparable<Employee>{
	double salary;
	Calendar hireDate;
	String insuranceNumber;
	public Employee(String name, String address,double salary,Calendar hireDate,String insuranceNumber) {
		super(name, address);
		this.salary = salary;
		this.hireDate = hireDate;
		this.insuranceNumber = insuranceNumber;
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	public String getAddress() {
		return address;
	}
	public double getSalary() {
		return salary;
	}
	public Calendar getHireDate() {
		return hireDate;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name+" "+address+" "+salary+" "+hireDate;
	}
	
	public boolean equals(Object o) {
		if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Employee e = (Employee) o;
        return (name == e.name) &&
        	   (address == e.address) &&
        	   (salary == salary) &&
        	   (hireDate == e.hireDate);		
	}
	
	public int hashCode() {
		int result = 0;
		int i = 1;
		result += Integer.parseInt(name)*(i++);
		result += Integer.parseInt(address)*(i++);
		result += salary*(i++);
		return result;
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		Employee other = (Employee) o;
		if(salary < other.salary) return -1;
		if(salary > other.salary) return 1;
		return 0;
	}
	
}
