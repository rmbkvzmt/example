CREATE DATABASE lab10;

CREATE TABLE accounts (
    id integer primary key,
    name varchar(20) not null,
    age int,
    balance int not null);

INSERT INTO accounts values (1, 'Anna', 35, 32000),
                            (2, 'Nurlam', 25, 45000),
                            (3, 'Adam', 21, 35000),
                            (4, 'Mishel', 19, 65000),
                            (5, 'Dana', 27, 75000),
                            (6, 'Kirill', 22, 95000),
                            (7, 'Zhanibek', 24, 37000);

BEGIN;
    UPDATE accounts SET balance = balance + 1000 WHERE id = 1;
    UPDATE accounts SET balance = balance + 20000 WHERE id = 2;
    UPDATE accounts SET balance = balance - 3000 WHERE id = 3;
ROLLBACK;

BEGIN;
    UPDATE accounts SET balance = balance - 1500 WHERE name = 'Kirill';
    UPDATE accounts SET balance = balance + 1500 WHERE name = 'Adam';
ROLLBACK;

BEGIN;
SAVEPOINT sp;
    DELETE FROM accounts where name = 'Dana';
ROLLBACK TO SAVEPOINT sp;
    UPDATE accounts SET balance = 70000 WHERE name = 'Dana';
COMMIT;

BEGIN;
    UPDATE accounts SET balance = balance - 3000 WHERE id = 3;
SAVEPOINT sp;
    UPDATE accounts SET balance = balance + 1000 WHERE id = 1 AND id = 2;
ROLLBACK TO sp;
COMMIT;
